import random

# Генератор пароля 1 с учетом цифр
def generate_with_digits(condition = False):
    digits = '0123456789'
    if condition:
        return list(digits)
    else:
        return []
        
# Генератор пароля 2 с учетом букв
def generate_with_letters(condition = False):
    letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    if condition:
        return list(letters)
    else:
        return []
    
# Генератор пароля 3 с учетом специальных символов
def generate_with_special(condition = False):
    special_symbols = r'!#$%&()*+-/:;<=>?@[\]^_{|}~'
    if condition:
        return list(special_symbols)
    else:
        return []
    
# Генератор итогового пароля
def password_generator(password_array, length):
    password = random.sample(password_array, length)
    return password