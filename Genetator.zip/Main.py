from tkinter import *
from tkinter import ttk
import Genetator

# Создаем окно
root = Tk()
root.geometry('700x600')
root.title('Password generator by Denis Svechin')

# Переменные
digits_enabled = BooleanVar()
letters_enabled = BooleanVar()
special_enabled = BooleanVar()
password_length_var = IntVar(value=1)  # Значение по умолчанию 8

# Функция копирования текста
def copy_to_clipboard():
    root.clipboard_clear()
    root.clipboard_append(password_res.cget("text"))
    root.update()

# Заголовки
welcome_label = ttk.Label(text="Welcome!", font=('Arial', 16))
welcome_label.pack()

description_label = ttk.Label(text="Select the appropriate parameters and press the button", font=('Arial', 13))
description_label.pack()

# Чекбоксы
digits_generator_checkbutton = ttk.Checkbutton(text='Digits', variable=digits_enabled)
digits_generator_checkbutton.pack()

letters_generator_checkbutton = ttk.Checkbutton(text='Letters', variable=letters_enabled)
letters_generator_checkbutton.pack()

special_generator_checkbutton = ttk.Checkbutton(text='Special symbols', variable=special_enabled)
special_generator_checkbutton.pack()

# Выбор длины пароля
password_length = ttk.Spinbox(from_=1, to=15, textvariable=password_length_var)
password_length.pack()

# Функция генерации пароля
def generate_password():
    sym1, sym2, sym3 = [], [], []  # Инициализация переменных
    
    if digits_enabled.get():
        sym1 = Genetator.generate_with_digits(condition=True)

    if letters_enabled.get():
        sym2 = Genetator.generate_with_letters(condition=True)

    if special_enabled.get():
        sym3 = Genetator.generate_with_special(condition=True)

    # Объединяем символы и генерируем пароль
    all_symbols = sym1 + sym2 + sym3
    length = password_length_var.get()

    if not all_symbols:
        password_res.config(text="Выберите хотя бы один параметр!")
        return

    password = Genetator.password_generator(all_symbols, length)
    password_res.config(text=password)

# Кнопка генерации
generate_button = ttk.Button(text='Generate', command=generate_password)
generate_button.pack()

# Вывод пароля
password_res = ttk.Label(text='Result:', font=('Arial', 14))
password_res.pack()

# Кнопка копирования
copy_button = ttk.Button(text="Copy to clipboard", command=copy_to_clipboard)
copy_button.pack()

# Запуск
root.mainloop()
